#ifndef COLORS_H
#define COLORS_H

//(BGR)
#define WHITE       0xFFFFFF
#define BLACK       0x000000
#define GREY        0x808080
#define BLUE        0xFF0000
#define GREEN       0x00FF00
#define RED         0x0000FF
#define YELLOW      0x00FFFF
#define ORANGE      0x00A5FF
#define DARKBLUE    0x8B0000
#define CYAN        0xEEEE00
#define DARKERCYAN  0xAAAA00

#endif