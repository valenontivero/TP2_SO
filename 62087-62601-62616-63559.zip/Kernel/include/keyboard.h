#ifndef KEYBOARD_H
#define KEYBOARD_H

void keyboard_handler();

char getChar();

extern unsigned char getKey();

#endif