#ifndef IDTLOADER_H_
#define IDTLOADER_H_

void load_idt(); // loads idt when OS starts

#endif